package com.classes.dao;

import com.classes.modal.Register;

public interface RegisterLoginDAO {

	boolean save(Register r);
}
